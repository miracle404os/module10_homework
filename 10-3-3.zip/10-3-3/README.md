# 10.3.3

A Pen created on CodePen.io. Original URL: [https://codepen.io/michael_sygurov/pen/qBGWJrK](https://codepen.io/michael_sygurov/pen/qBGWJrK).

