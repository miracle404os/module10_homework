# 10.5.2

A Pen created on CodePen.io. Original URL: [https://codepen.io/michael_sygurov/pen/qBGWJLL](https://codepen.io/michael_sygurov/pen/qBGWJLL).

