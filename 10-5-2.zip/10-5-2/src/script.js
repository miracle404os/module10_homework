const btn = document.querySelector('.btn-test');

btn.addEventListener("click",() => {
  window.alert(('Ширина вашего экрана: ' )(window.screen.width) , 'а высота: '(window.screen.height));
});